package dao;

import model.Veiculo;

import java.util.ArrayList;
import java.util.List;

public class VeiculoDAO {
    //Nessa classe implementamos nosso CRUD e demais ações com o BD
    public void inserir(Veiculo veiculo){
        //TODO
    }
    public Veiculo pesquisar(Veiculo veiculo){
        return veiculo;
    }
    public void atualizar(Veiculo veiculo){
        //TODO
    }
    public void excluir(Veiculo veiculo){
        //TODO
    }
    public List<Veiculo> listar(){
        return new ArrayList<>();
    }
}
