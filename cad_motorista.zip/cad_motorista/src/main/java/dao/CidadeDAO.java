package dao;

import model.Cidade;

import java.util.ArrayList;
import java.util.List;

public class CidadeDAO {

    //Nessa classe implementamos nosso CRUD e demais ações com o BD
    public void inserir(Cidade cidade){
        //TODO
    }
    public Cidade pesquisar(Cidade cidade){
        return cidade;
    }
    public void atualizar(Cidade cidade){
        //TODO
    }
    public void excluir(Cidade cidade){
        //TODO
    }
    public List<Cidade> listar(){
        return new ArrayList<>();
    }
}
